<?php

namespace App\Controllers;

class User extends BaseController{
    
}