<footer class="footer pt-0">
    <script src="/assets/admin/vendor/jquery/dist/jquery.min.js"></script>
    <script src="/assets/admin/peekabar/js/jquery.peekabar.min.js" type="text/javascript"></script>
    <script src="/assets/admin/jquery-confirm/jquery-confirm.min.js" type="text/javascript"></script>
    <script type="text/javascript" src="./assets/admin/js/scripts/topnav.js"></script>
    <div class="row align-items-center justify-content-lg-between">
        <div class="col-lg-6">
            <div class="copyright text-center text-lg-left text-muted">
                &copy; <?=date('Y');?> Open Source Communitites
            </div>
        </div>
        <div class="col-lg-6 text-right">
            <small>Mabuhay ang komunidad ng mga malalaya</small>
        </div>
    </div>
</footer>